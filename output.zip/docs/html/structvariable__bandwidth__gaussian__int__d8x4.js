var structvariable__bandwidth__gaussian__int__d8x4 =
[
    [ "operator()", "structvariable__bandwidth__gaussian__int__d8x4.html#a1a204b6c4adb4d81285c86dcc0de96b0", null ]
];