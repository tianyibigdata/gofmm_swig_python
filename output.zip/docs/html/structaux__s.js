var structaux__s =
[
    [ "a_next", "structaux__s.html#a209e461c072724abe8e16f57ed0d52de", null ],
    [ "b", "structaux__s.html#a3f538b41172720a0963736503e358453", null ],
    [ "b_next", "structaux__s.html#a4971928e0869a355da875c4acc6db7b0", null ],
    [ "c_buff", "structaux__s.html#a3e957a245134e3776b7e6c0390e9ee53", null ],
    [ "do_packC", "structaux__s.html#a43bacbed30c83b37b28144d24ce64db9", null ],
    [ "hi", "structaux__s.html#a0669a0e52541fa2464301681a49a9eee", null ],
    [ "hj", "structaux__s.html#a7bbbf14794ea8db8c6a8bd62ee06d448", null ],
    [ "i", "structaux__s.html#abb050bb9bb349fe948b749ddba169546", null ],
    [ "ib", "structaux__s.html#a626d33fcdae3d1a3432aaf853462bf2f", null ],
    [ "j", "structaux__s.html#a942810acc8365697313077d8fd95db0b", null ],
    [ "jb", "structaux__s.html#ae9a1e87e83a5c397a88624782afa0a44", null ],
    [ "ldc", "structaux__s.html#a792e1dc533c69f849dee584b2a50c9de", null ],
    [ "ldv", "structaux__s.html#a5a017569332a0b06d7cb25a0d2974815", null ],
    [ "m", "structaux__s.html#a3ca179af3e1f7f9673c79e297ee53c0a", null ],
    [ "n", "structaux__s.html#ae09f8a436ef06125ad240426f76af71e", null ],
    [ "pc", "structaux__s.html#af0482ef0acd020289bbcdd34715a7c7a", null ],
    [ "V", "structaux__s.html#a4f476296157b751be288a3ccf644b5de", null ]
];