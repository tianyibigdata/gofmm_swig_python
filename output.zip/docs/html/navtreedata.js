var NAVTREE =
[
  [ "HMLP: High-performance Machine Learning Primitives", "index.html", [
    [ "HMLP (High Performance Machine Learning Primitives)", "index.html", null ],
    [ "Namespaces", null, [
      [ "Namespace List", "namespaces.html", "namespaces" ],
      [ "Namespace Members", "namespacemembers.html", [
        [ "All", "namespacemembers.html", null ],
        [ "Functions", "namespacemembers_func.html", null ],
        [ "Enumerations", "namespacemembers_enum.html", null ],
        [ "Enumerator", "namespacemembers_eval.html", null ]
      ] ]
    ] ],
    [ "Classes", "annotated.html", [
      [ "Class List", "annotated.html", "annotated_dup" ],
      [ "Class Index", "classes.html", null ],
      [ "Class Hierarchy", "hierarchy.html", "hierarchy" ],
      [ "Class Members", "functions.html", [
        [ "All", "functions.html", "functions_dup" ],
        [ "Functions", "functions_func.html", "functions_func" ],
        [ "Variables", "functions_vars.html", null ],
        [ "Typedefs", "functions_type.html", null ]
      ] ]
    ] ],
    [ "Files", null, [
      [ "File List", "files.html", "files" ]
    ] ]
  ] ]
];

var NAVTREEINDEX =
[
".html",
"classhmlp_1_1_event.html#ab8de7440d8421010c9341f89fc9a08c8",
"classhmlp_1_1_task.html#ab41f10d289d99f94e37d74ac17bbba52",
"classhmlp_1_1gofmm_1_1_near_samples_task.html#a271bb4826120bbfea3440644042adaa2",
"classhmlp_1_1mpigofmm_1_1_l2_l_task2.html",
"classhmlp_1_1tree_1_1_setup.html",
"index.html",
"structknn__int__s12x32.html#af410b8f5606739eede83f1636924cc7b"
];

var SYNCONMSG = 'click to disable panel synchronisation';
var SYNCOFFMSG = 'click to enable panel synchronisation';