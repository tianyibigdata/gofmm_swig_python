var classpvfmm_1_1_basis_interface =
[
    [ "BasisInterface", "classpvfmm_1_1_basis_interface.html#ac47d3a22f23ebea63f493ede72aef1e9", null ],
    [ "Derived", "classpvfmm_1_1_basis_interface.html#a8cadd43ee89b82c321d9ac9d11dabc10", null ]
];