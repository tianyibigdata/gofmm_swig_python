var structrank__k__asm__s16x6 =
[
    [ "GEMM_OPERATOR", "structrank__k__asm__s16x6.html#ae83ccf93003dab4fc74c7f804fc7aca1", null ],
    [ "operator()", "structrank__k__asm__s16x6.html#a44c5a24b4634e0e638127d6dbc2b1375", null ],
    [ "STRA_OPERATOR", "structrank__k__asm__s16x6.html#af8cb1a41e0ce7995ac9dc341f8f93943", null ]
];