var structvariable__bandwidth__gaussian__ref__d8x4 =
[
    [ "operator()", "structvariable__bandwidth__gaussian__ref__d8x4.html#a02685e6e5ab74c7148a04e2ed9e60883", null ]
];