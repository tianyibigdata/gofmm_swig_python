var structknn__int__d6x32 =
[
    [ "operator()", "structknn__int__d6x32.html#a4352205c0dbfd248b03e4b01702bd033", null ],
    [ "align_size", "structknn__int__d6x32.html#a279051cb07a4eb674a0cae28e5482399", null ],
    [ "mr", "structknn__int__d6x32.html#ae5aa5c0a19854dfec74cec472c98425d", null ],
    [ "nr", "structknn__int__d6x32.html#a61083d4d440d8f5061174de96eac0d91", null ],
    [ "pack_mr", "structknn__int__d6x32.html#a74596d044467b0899f28179dbbcbfdc3", null ],
    [ "pack_nr", "structknn__int__d6x32.html#a724643915571ae8d86722bfc63480789", null ],
    [ "row_major", "structknn__int__d6x32.html#a7bbf7914fc021c15da048e37ac5d9195", null ]
];